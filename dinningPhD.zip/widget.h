﻿#ifndef WIDGET_H
#define WIDGET_H
#include "chopstick.h"
#include "const.h"
#include "philosopher.h"
#include <QWidget>
#include <QVector>
#include <QtMath>
#include <QSemaphore>
#include <QDebug>
#include <QPushButton>
#include <QMouseEvent>
#include <QTimer>
namespace Ui {
class Widget;

}

class Widget : public QWidget
{
Q_OBJECT
public:
int timerID;
Philosopher* philosophers[MAXN];
ChopStick* chopsticks[MAXN];
QSemaphore* sem[5];
QSemaphore* full;
explicit Widget(QWidget *parent = nullptr);
~Widget();
void paintEvent(QPaintEvent *);

void mousePressEvent(QMouseEvent* event)
{
    qDebug()<<event->pos();
}

private:
Ui::Widget *ui;
};

#endif // WIDGET_H
