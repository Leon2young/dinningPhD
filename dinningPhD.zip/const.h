﻿#ifndef CONST_H
#define CONST_H

const int MAXN = 5;
const int REST = 0;
const int THINK = 1;
const int EAT = 2;
const int LEFT = 3;
const int RIGHT = 4;
const int FULL = 5;
const int INIT = 0;
const int CIRCLE_X = 295;
const int CIRCLE_Y = 320;
const int MIN_RADIUS = 210;
const int MAX_RADIUS = 280;
const char STATUS_NAME[6][10] = {"休息", "思考", "吃饭", "左筷", "右筷", "双筷"};
const int INIT_POS[5][3] = {
    {390, 240, 36},
    {440, 405, 108},
    {308, 506, 180},
    {168, 410, 252},
    {224, 242, 324},
};

const int SET_POS[2][5][3] = {
    {//放左筷
        {350, 215, 0},
        {462, 363, 72},
        {355, 505, 144},
        {190, 455, 218},
        {185, 280, 288},
    },
    {//放右筷
        {260, 215, 0},
        {430, 275, 72},
        {430, 440, 144},
        {260, 510, 218},
        {155, 370, 288}
    }
};

const int SIZE = 1;
#endif // CONST_H
