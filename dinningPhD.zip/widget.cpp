﻿#include "widget.h"
#include "ui_widget.h"
#include <QPainter>
#include <QDebug>
#include <QSemaphore>
#include <QTimer>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("哲学家就餐问题");

    this->resize( QSize( 750, 660 ));
    QPalette palette(this->palette());
    palette.setColor(QPalette::Window, Qt::white);
    this->setPalette(palette);

    for(int i = 0; i < MAXN; i++)
    {
        sem[i] = new QSemaphore(1);
    }
    full = new QSemaphore(4); // 最多四个人同时拿起左筷
    philosophers[0] = new Philosopher(0, 429, 140, 0, this, this->sem, this->chopsticks,this->full);
    philosophers[1] = new Philosopher(1, 510, 398, 72, this, this->sem, this->chopsticks,this->full);
    philosophers[2] = new Philosopher(2, 480, 635, 144, this, this->sem, this->chopsticks,this->full);
    philosophers[3] = new Philosopher(3, 172, 632, 216, this, this->sem, this->chopsticks,this->full);
    philosophers[4] = new Philosopher(4, 48, 398, 288, this, this->sem, this->chopsticks,this->full);
    chopsticks[0] = new ChopStick(0, 390, 240, 36, this);
    chopsticks[1] = new ChopStick(1, 440, 405, 108, this);
    chopsticks[2] = new ChopStick(2, 308, 506, 180, this);
    chopsticks[3] = new ChopStick(3, 168, 410, 252, this);
    chopsticks[4] = new ChopStick(4, 224, 242, 324, this);

    QTimer *timer  = new QTimer;
    ui->fast->setChecked(1);
    static int sp=500;//延时控制
    connect(ui->startbt,&QPushButton::clicked,[=]()
    {
        timer->start(sp);
        for(int i = 0; i < MAXN; i++)
        {
            philosophers[i]->start();
        }

    });
    connect(ui->stopbt,&QPushButton::clicked,[=]()
    {
        timer->stop();
    });
    connect(ui->resetbt,&QPushButton::clicked,[=]()
    {
        timer->stop();
        for(int i=0; i<MAXN; i++)
        {
            philosophers[i]->status = REST;
            chopsticks[i]->initPos(i);
        }
        update();
        timer->stop();
    });
    connect(timer,&QTimer::timeout,[=]()
    {
        update();
    });
    connect(ui->fast,&QRadioButton::clicked,[=]()
    {
        sp=500;
        timer->setInterval(sp);
    });

    connect(ui->medium,&QRadioButton::clicked,[=]()
    {
        sp=1500;
        timer->setInterval(sp);
    });
    connect(ui->slow,&QRadioButton::clicked,[=]()
    {
        sp=3000;
        timer->setInterval(sp);
    });
}

Widget::~Widget()
{
    delete ui;
}

void Widget::paintEvent(QPaintEvent *)
{
    QPainter pen(this);
    QPixmap img;
    img.load(":/new/prefix1/pic/table.png");
    pen.drawPixmap(0, 60, 600, 600, img);
    for(int i = 0; i < MAXN; i++)
    {
        philosophers[i]->draw(&pen);
        chopsticks[i]->draw(&pen);
    }
}




