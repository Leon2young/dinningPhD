﻿#ifndef PHILOSOPHER_H
#define PHILOSOPHER_H
#include <QThread>
#include <QPainter>
#include "const.h"
#include "chopstick.h"
#include <QSemaphore>
#include <QRandomGenerator>
#include <QWidget>
#include <QMutex>
class Philosopher : public QThread
{
Q_OBJECT
public:
int x, y;
int id;
int status;
double rotate;
QWidget *father;
ChopStick** chopsticks;
QSemaphore** sem;
QSemaphore* full;
void run();
Philosopher(int id, int x, int y, int rotate, QWidget* fa, QSemaphore** sem, ChopStick** chopsticks, QSemaphore* full);
void draw(QPainter *);
~Philosopher();
};

#endif // PHILOSOPHER_H
